import React, { useState } from 'react';
import { login } from '../utils/api'; // Import the updated login function from api.js

const Login = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); // Show a loading state during the API call
    setError(''); // Reset any previous errors

    try {
      const response = await login(email, password); // Call the updated login function
      if (response.token) {
        onLogin(response.token); // Pass the token to the parent component or save it
      } else {
        setError(response.error || 'Login failed'); // Display an error message from the backend
      }
    } catch (err) {
      console.error('Login Error:', err);
      setError('An error occurred during login. Please try again.'); // Handle unexpected errors
    } finally {
      setLoading(false); // Reset the loading state
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            placeholder="Enter your email"
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            placeholder="Enter your password"
          />
        </div>
        {error && <p className="error-message">{error}</p>} {/* Display error messages */}
        <button type="submit" disabled={loading}>
          {loading ? 'Logging in...' : 'Login'}
        </button>
      </form>
    </div>
  );
};

export default Login;
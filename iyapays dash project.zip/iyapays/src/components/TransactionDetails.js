import React from 'react';
import { ArrowLeft } from 'lucide-react';

const TransactionDetails = ({ transaction, onClose }) => (
  <div className="p-6 bg-white rounded-lg">
    <div className="flex items-center justify-between mb-6">
      <h2 className="text-2xl font-bold">Transaction Details</h2>
      <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
        <ArrowLeft className="w-6 h-6" />
      </button>
    </div>
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-gray-500">Date</p>
          <p className="font-medium">{transaction.date}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Amount</p>
          <p className="font-medium">${transaction.amount}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Type</p>
          <p className="font-medium capitalize">{transaction.type}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Status</p>
          <p className="font-medium capitalize">{transaction.status}</p>
        </div>
      </div>
      <div className="border-t pt-4">
        <h3 className="text-lg font-semibold mb-3">Sender Details</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-500">Name</p>
            <p className="font-medium">{transaction.sender}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Account Number</p>
            <p className="font-medium">{transaction.senderAccount}</p>
          </div>
        </div>
      </div>
      <div className="border-t pt-4">
        <h3 className="text-lg font-semibold mb-3">Recipient Details</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-500">Name</p>
            <p className="font-medium">{transaction.recipient}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Account Number</p>
            <p className="font-medium">{transaction.recipientAccount}</p>
          </div>
        </div>
      </div>
      <div>
        <p className="text-sm text-gray-500">Description</p>
        <p className="font-medium">{transaction.description}</p>
      </div>
    </div>
  </div>
);

export default TransactionDetails;
import React from 'react';
import { ArrowLeft } from 'lucide-react';

const UserProfile = ({ user, onClose, setSelectedTransaction }) => (
  <div className="bg-white p-6 rounded-lg">
    <div className="flex items-center justify-between mb-6">
      <h2 className="text-2xl font-bold">User Profile</h2>
      <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
        <ArrowLeft className="w-6 h-6" />
      </button>
    </div>
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-gray-500">Name</p>
          <p className="font-medium">{user.name}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Email</p>
          <p className="font-medium">{user.email}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Phone</p>
          <p className="font-medium">{user.phoneNumber}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Account Number</p>
          <p className="font-medium">{user.accountNumber}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Balance</p>
          <p className="font-medium">${user.balance.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Account Type</p>
          <p className="font-medium">{user.accountType}</p>
        </div>
      </div>
      <div>
        <p className="text-sm text-gray-500">Address</p>
        <p className="font-medium">{user.address}</p>
      </div>
      <div>
        <h3 className="text-lg font-semibold mb-3">Transaction History</h3>
        <div className="space-y-2">
          {user.transactions.map(transaction => (
            <div 
              key={transaction.id}
              className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
              onClick={() => setSelectedTransaction(transaction)}
            >
              <div className="flex justify-between">
                <span>{transaction.date}</span>
                <span className={transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'}>
                  {transaction.type === 'credit' ? '+' : '-'}${transaction.amount}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

export default UserProfile;
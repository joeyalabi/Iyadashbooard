import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import UserProfile from '../components/UserProfile';
import TransactionDetails from '../components/TransactionDetails';
import Charts from '../components/Charts';
import { fetchUsers, fetchTransactionHistory, fetchExpenseBreakdown } from '../utils/api';

const Dashboard = ({ authToken }) => {
  const [users, setUsers] = useState([]);
  const [transactionHistory, setTransactionHistory] = useState([]);
  const [expenseBreakdown, setExpenseBreakdown] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedTransaction, setSelectedTransaction] = useState(null);

  useEffect(() => {
    fetchUsers(authToken).then(setUsers);
    fetchTransactionHistory(authToken).then(setTransactionHistory);
    fetchExpenseBreakdown(authToken).then(setExpenseBreakdown);
  }, [authToken]);

  if (!authToken) {
    return <Navigate to="/login" />;
  }

  const renderContent = () => {
    if (selectedUser) {
      return <UserProfile user={selectedUser} onClose={() => setSelectedUser(null)} setSelectedTransaction={setSelectedTransaction} />;
    }

    if (selectedTransaction) {
      return <TransactionDetails transaction={selectedTransaction} onClose={() => setSelectedTransaction(null)} />;
    }

    return (
      <>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Total Balance</h3>
            </div>
            <div className="card-content">
              <p className="text-2xl font-bold">$45,231.89</p>
              <p className="text-xs text-gray-500">+20.1% from last month</p>
            </div>
          </div>
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Monthly Income</h3>
            </div>
            <div className="card-content">
              <p className="text-2xl font-bold">$12,234.00</p>
              <p className="text-xs text-gray-500">+4.3% from last month</p>
            </div>
          </div>
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Active Cards</h3>
            </div>
            <div className="card-content">
              <p className="text-2xl font-bold">3</p>
              <p className="text-xs text-gray-500">2 credit, 1 debit</p>
            </div>
          </div>
        </div>

        <Charts transactionHistory={transactionHistory} expenseBreakdown={expenseBreakdown} />
      </>
    );
  };

  return (
    <div className="dashboard">
      {renderContent()}
    </div>
  );
};

export default Dashboard;
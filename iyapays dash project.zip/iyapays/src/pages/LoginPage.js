import React from 'react';
import { useNavigate } from 'react-router-dom';
import Login from '../components/Login';

const LoginPage = ({ setAuthToken }) => {
  const navigate = useNavigate();

  const handleLogin = (token) => {
    setAuthToken(token);
    navigate('/dashboard');
  };

  return (
    <div className="login-page">
      <Login onLogin={handleLogin} />
    </div>
  );
};

export default LoginPage;
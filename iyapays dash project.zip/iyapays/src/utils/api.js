export const fetchUsers = async (token) => {
  const response = await fetch('http://localhost:5000/api/users', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.json();
};

export const fetchTransactionHistory = async (token) => {
  const response = await fetch('http://localhost:5000/api/transaction-history', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.json();
};

export const fetchExpenseBreakdown = async (token) => {
  const response = await fetch('http://localhost:5000/api/expense-breakdown', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.json();
};
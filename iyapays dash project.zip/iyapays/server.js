const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Sample data
const users = [
  // Your user data here
];

const transactionHistory = [
  // Your transaction history data here
];

const expenseBreakdown = [
  // Your expense breakdown data here
];

// Dummy user for authentication
const dummyUser = {
  email: 'test@example.com',
  password: 'password123',
  token: 'dummy-token',
};

// Login endpoint
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  if (email === dummyUser.email && password === dummyUser.password) {
    res.json({ success: true, token: dummyUser.token });
  } else {
    res.json({ success: false, message: 'Invalid email or password' });
  }
});

// Auth middleware
const authenticate = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (token === dummyUser.token) {
    next();
  } else {
    res.sendStatus(403);
  }
};

// Protected endpoints
app.get('/api/users', authenticate, (req, res) => {
  res.json(users);
});

app.get('/api/transaction-history', authenticate, (req, res) => {
  res.json(transactionHistory);
});

app.get('/api/expense-breakdown', authenticate, (req, res) => {
  res.json(expenseBreakdown);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});